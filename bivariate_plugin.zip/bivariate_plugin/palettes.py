# palettes.py — All 30 bivariate palettes
# Format: palette_name -> list of 9 hex codes [11,12,13,21,22,23,31,32,33]

PALETTES = {
    "Bluegill":           ["#d3d3d3","#b59a7a","#976020","#a4bdbb","#8c8a6c","#75561c","#74a7a3","#647a5e","#534c19"],
    "BlueGold":           ["#d3d3d3","#d8bd75","#dea301","#8fb1c2","#929f6c","#968901","#488fb0","#498062","#4c6e01"],
    "BlueOr":             ["#d3d3d3","#7ebbd2","#169dd0","#d8a386","#819185","#167984","#dd6a29","#845e29","#174f28"],
    "BlueYl":             ["#d3d3d3","#74b1d6","#0088d9","#d6cb7d","#76ab7e","#008380","#d9be00","#78a000","#007b00"],
    "Brown":              ["#e8e8e8","#cbb8d7","#9972af","#e4d9ac","#c8ada0","#976b82","#c8b35a","#af8e53","#804d36"],
    "Brown2":             ["#d3d3d3","#af9cb9","#8b689f","#c5bb93","#a38b81","#825c6f","#b6a352","#977948","#78503e"],
    "DkBlue":             ["#e8e8e8","#dfb0d6","#be64ac","#ace4e4","#a5add3","#8c62aa","#5ac8c8","#5698b9","#3b4994"],
    "DkBlue2":            ["#d3d3d3","#c098b9","#ad5b9c","#97c5c5","#898ead","#7c5592","#52b6b6","#4a839f","#434e87"],
    "DkCyan":             ["#e8e8e8","#b8d6be","#73ae80","#b5c0da","#90b2b3","#5a9178","#6c83b5","#567994","#2a5a5b"],
    "DkCyan2":            ["#d3d3d3","#9eb9a4","#699e74","#9aa5bb","#739091","#4c7c67","#6277a5","#4a6880","#31595b"],
    "DkViolet":           ["#cabed0","#89a1c8","#4885c1","#bc7c8f","#806a8a","#435786","#ae3a4e","#77324c","#3f2949"],
    "DkViolet2":          ["#d3d3d3","#8aa6c2","#4279b0","#ba8890","#7a6b84","#3a4e78","#9e3547","#682a41","#311e3b"],
    "GrPink":             ["#e8e8e8","#b0d5df","#64acbe","#e4acac","#ad9ea5","#627f8c","#c85a5a","#985356","#574249"],
    "GrPink2":            ["#d3d3d3","#98b8c0","#5b9cad","#c59595","#8e8288","#556f7a","#b65252","#83474a","#4e3d43"],
    "PinkGrn":            ["#d3d3d3","#ca85af","#bc177d","#90b87e","#8a7469","#80144b","#459b22","#42611c","#3e1114"],
    "PurpleGrn":          ["#d3d3d3","#a180ac","#6f2d85","#70a985","#55676c","#3b2454","#027a2e","#014a26","#011a1d"],
    "PurpleOr":           ["#d3d3d3","#9283ac","#563787","#d39c75","#926160","#56284b","#d25601","#923601","#551601"],
    "PinkGrn2":           ["#F7FCF5","#F78FB6","#F73593","#A5E8CD","#A58FB6","#A53593","#40DBA7","#408FA7","#403593"],
    "BlueRed":            ["#D2DEEE","#84A6D9","#366EC3","#D797A3","#877194","#374B85","#D72528","#871C25","#371321"],
    "GrenYellow":         ["#EAF1EB","#9CF9E1","#00F9BB","#F0DF79","#A0E673","#00E660","#F0C600","#A0CC00","#00CC00"],
    "GreenPurple":        ["#EEFEE2","#ABD8F1","#65AFFE","#C6DE8D","#8D9F9B","#7263A9","#9EBE39","#79794C","#78379B"],
    "BlueYellowBlack":    ["#E7E5F1","#F2D279","#F2B200","#A1C7DA","#8D916D","#795900","#4F9CC1","#274E60","#020202"],
    "PaleRedBlue":        ["#F1F1F1","#F8B7B7","#FE7272","#A2EBF3","#A598D4","#935B8F","#62E7F4","#5593D4","#593FB3"],
    "GreenPinkPurple":    ["#F2F2F2","#CADA92","#A1C226","#E5B2EA","#B19C90","#75936A","#D571E0","#7F6FAD","#4B62A2"],
    "BlueGreenPurple":    ["#F3FFE9","#BBE1F4","#86C0FE","#D2E6A6","#A5B3B1","#8E83BB","#B2CC61","#959470","#955EB0"],
    "BlueYellow":         ["#E9E9EB","#A3C6DA","#55A5C7","#ECD088","#A6B37E","#579574","#F5B903","#AEA003","#5D8103"],
    "BlueOrange":         ["#FEF2E5","#97D1E8","#18AFE5","#FAB186","#B0988D","#407A8F","#F3742C","#AB5E36","#5C463C"],
    "PaleblueRed":        ["#E6F9FF","#EBADC8","#F2467E","#99D7F0","#9D96BC","#A13D77","#46B4E0","#487DB0","#4A336F"],
    "PurpleGreen2":       ["#F1EBFF","#C3B5E9","#9580D4","#AEDDB7","#8CAAA7","#6B7898","#60CC63","#4E9C5A","#3B6F52"],
}

CODE_LABELS = {
    "11": "Low A, Low B",    "12": "Low A, Mid B",    "13": "Low A, High B",
    "21": "Mid A, Low B",    "22": "Mid A, Mid B",    "23": "Mid A, High B",
    "31": "High A, Low B",   "32": "High A, Mid B",   "33": "High A, High B",
}
