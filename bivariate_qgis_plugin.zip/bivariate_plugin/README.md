# Bivariate QGIS Plugin
**Ultimate Palette Studio — 30 palettes · 7 tools · Vector + Raster + Web export**

---

## Installation

**Option A — Install from ZIP (recommended):**
1. QGIS → Plugins → Manage and Install Plugins → Install from ZIP
2. Select `bivariate_qgis_plugin.zip` → Install Plugin
3. Enable "Bivariate QGIS Plugin" in the Installed tab
4. All tools appear under **Processing Toolbox → Bivariate QGIS Plugin → Cartography**

**Option B — Manual:**
Unzip into your QGIS plugins folder:
- Windows: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
- macOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
- Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`

Restart QGIS → Plugins → Enable "Bivariate QGIS Plugin".

---

## Tools (7 total)

### 1. Bivariate Choropleth Classification
Classifies two numeric fields into a 3×3 bivariate scheme.

- **Input:** Any polygon layer with two numeric fields
- **Output:** Copy of the layer with added `Var1_Class` (1-3), `Var2_Class` (A-C), `Bi_Class` (A1–C3)
- **Methods:** Quantile (recommended) · Natural Breaks · Equal Interval

---

### 2. Apply Bivariate Color Scheme
Styles a layer with a `Bi_Class` field using any of 30 built-in palettes.

- **Input:** Layer with `Bi_Class` field (A1–C3) — from Tool 1
- **Palette selector:** All 30 palettes listed by name
- **Custom option:** Paste 9 comma-separated hex codes (order: A1, A2, A3, B1, B2, B3, C1, C2, C3)

---

### 3. Bivariate Legend Box Generator (3×3) ★ Layout Icon Support
Creates a 3×3 grid of **square** polygon boxes for use as a legend.

**Layout Icon Feature:**
- The layer loads with a **Categorized renderer** on the `code` field
- Each of the 9 classes (11–33) has its own colored square icon
- In **Print Layout → Add Legend**, each class appears as a colored square icon
- **To recolor interactively:** Layer Properties → Symbology → double-click any color swatch
- The legend in Print Layout updates live as you change colors

**Fields:** `code`, `label`, `color`, `a_class`, `b_class`, `row`, `col`

Optional: enable **"Add class code labels"** to show `11`, `22`, `33`... on each box.

---

### 4. Bivariate Legend Diamond Generator (3×3) ★ Layout Icon Support
Creates a 3×3 grid of **diamond (rhombus)** shapes in a 45°-rotated layout.

- Variable A increases along the bottom-right diagonal
- Variable B increases along the bottom-left diagonal
- Same layout icon and recoloring support as the Box Generator

---

### 5. Bivariate Raster Generator
Classifies two rasters into terciles (1/2/3 each) and combines them into bivariate pixel codes 11–33.

- **Options:** Reproject & align grids to Raster A, optional divisor for Raster B
- **Output:** Raster A class (1-3), Raster B class (1-3), Bivariate combined raster (11-33)

---

### 6. Bivariate Style Generator
Writes a `.qml` color style file for bivariate rasters (pixel values 11–33).

- Choose from 30 palettes or supply custom hex codes
- **Auto-apply** directly to the selected raster layer
- Output `.qml` file can be loaded via Layer Properties → Symbology → Load Style

---

### 7. Bivariate Leaflet Exporter ★ Fully Styled
Exports a bivariate vector layer to a **standalone Leaflet HTML map** — no grey.

**Features:**
- ✅ Full palette-matched fill and outline colors (no grey/placeholder)
- ✅ Styled sidebar: title, subtitle, bivariate legend, variable descriptions
- ✅ Interactive legend: hover a cell → highlights matching regions on the map
- ✅ Class distribution chips (click to filter map)
- ✅ Hover tooltip + click popup with all attribute values
- ✅ Dark/light theme toggle button
- ✅ Basemap switcher: CartoDB Positron · CartoDB Dark Matter · OpenStreetMap · Stamen Toner Lite
- ✅ Scale bar, zoom controls, fullscreen button
- ✅ Extra popup fields: choose specific fields or expose all attributes

---

## The 30 Palettes

| Group | Palettes |
|-------|---------|
| Classic | Bluegill, BlueGold, BlueOr, BlueYl, Brown, Brown2 |
| Dark | DkBlue, DkBlue2, DkCyan, DkCyan2, DkViolet, DkViolet2 |
| Warm | GrPink, GrPink2, PinkGrn, PurpleGrn, PurpleOr, PinkGrn2 |
| Vivid | BlueRed, GrenYellow, GreenPurple, BlueYellowBlack |
| Pale | PaleRedBlue, GreenPinkPurple, BlueGreenPurple, BlueYellow, BlueOrange, PaleblueRed, PurpleGreen2 |

---

## Typical Workflows

```
Vector workflow:
  Polygon layer
    → [1] Bivariate Choropleth Classification  (adds Bi_Class field)
    → [2] Apply Bivariate Color Scheme         (styles the layer)
    → [3] Legend Box Generator                 (3×3 inset legend for print)
    → [4] Legend Diamond Generator             (rotated inset legend for print)
    → [7] Bivariate Leaflet Exporter           (web map)

Raster workflow:
  Raster A + Raster B
    → [5] Bivariate Raster Generator           (creates 11-33 coded raster)
    → [6] Bivariate Style Generator            (QML style file)
```

---

## Credits
- Bivariate methodology: [Joshua Stevens](https://www.joshuastevens.net/cartography/make-a-bivariate-choropleth-map/)
- Web export inspired by [qgis2web](https://github.com/tomchadwin/qgis2web)
- Palettes from the bivariate cartography community
